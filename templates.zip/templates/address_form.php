    <h1>Learn about your representitives</h1>
    <h2>Enter your address to find your representitives</h2>
     <form class="form-inline" id="form" role="form" method="get" action="/test.php"  >
                <div class="form-group">
                    <label >Enter your address</label>
                    <input class="form-control" id="" placeholder="City, State, Postal Code" type="text" name ="address"/>
                     <input type="submit" value="submit">
                    
                </div>
            </form>
            
            
    




<!--<div class="fb-login-button" data-max-rows="1" data-size="medium" data-show-faces="false" data-auto-logout-link="true" scope="public_profile,email" onlogin="checkLoginState()></div> -->
