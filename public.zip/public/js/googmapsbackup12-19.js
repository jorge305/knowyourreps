

var myLatLng;

var map;

var marker;

var reps = [];

var markers = [];

var cntm = 0;

var info = new google.maps.InfoWindow();


 

$(function() {

$.getJSON("geoaddr.php?address=10843+SW+69th+DR.+Miami")
   .done(function(data, textStatus, jqXHR) {
    console.log("first data: " + data);

myLatLng = data; 
//console.log("here"+myLatLng);  

initMap(myLatLng);
/*
marker = new google.maps.Marker({
    position: myLatLng,
    map: map,
    animation: google.maps.Animation.DROP,
    title: 'Hello World!'
  });

marker.addListener('click', toggleBounce);
*/



}) 


$.getJSON("repsjson.php")
   .done(function(data, textStatus, jqXHR) {
    console.log("repjson"+data[1]);

    reps = data;

    //console.log("reps name "+reps[1].name);

    //console.log("reps address "+reps[1].address[0].line1);

//console.log("b4 for loop");
//console.log("ength " + reps.length);
//console.log(reps);


for (var i = 0, len = reps.length; i < len; i++)
    {
    	console.log("for loop " + cntm);
    	addMarker(reps[i]);
    	if (cntm = 0)
    	{
    		i--;
    	}
    	console.log("for loop after" + markers[cntm - 1]);
    }
   

}) 


});
   


//console.log("here"+myLatLng);
function initMap(myLatLng) {
  map = new google.maps.Map(document.getElementById('map'), {
    center: myLatLng,
    zoom: 10
  });
}

function toggleBounce() {
  if (marker.getAnimation() !== null) {
    marker.setAnimation(null);
  } else {
    marker.setAnimation(google.maps.Animation.BOUNCE);
  }
}

function addMarker(repsinfo)
{


	//console.log("add marker running" + myLatLng);

	if (repsinfo.address !== null)
		{
			first = "geoaddr.php?address="
	repaddr = repsinfo.address[0].line1;
	repaddr += repsinfo.address[0].line2;
	repaddr += " " + repsinfo.address[0].city;
	repaddr += " " + repsinfo.address[0].state;
	repaddr += " " + repsinfo.address[0].zip;
	first += encodeURIComponent(repaddr);
	//console.log("econde url " + first);

	


console.log("berfore ajax")
$.ajax({
  url: first,
  async: true,
}).done(function(data, textStatus, jqXHR) {
  


/*

	$.getJSON(first)
   .done(function(data, textStatus, jqXHR) {
  
*/
    //console.log(data);

    myLatLng = data;
    //console.log(myLatLng);

    //console.log("post getRepAddr" + myLatLng);
/*
	marker = new google.maps.Marker({
    position: myLatLng,
    map: map,
    animation: google.maps.Animation.DROP,
    title: 'Hello World!'
  });
*/
//marker.addListener('click', toggleBounce);

	repsaddr = '<h1 id="firstHeading" class="firstHeading">' + repsinfo.name + '</h1><ul>';
	console.log("before if " + repsinfo.address);
	//console.log("type of address " + typeof(repsinfo.address[0]));
	if (repsinfo.address !== null) 
	{
		console.log("line1 " + repsinfo.address[0].line1)
		if (typeof(repsinfo.address[0].line1) !== "undefined" || repsinfo.address[0].line1 !== null)
		{
		repsaddr += "<div><li>" + repsinfo.address[0].line1 + "<br>";
		}
		if 	(typeof(repsinfo.address[0].line2) !== "undefined" || repsinfo.address[0].line2 !== null)
			{

			repsaddr += "<div><li>" + repsinfo.address[0].line2 + "<br>";

			}

		repsaddr += repsinfo.address[0].city + ", " + repsinfo.address[0].state + " " + repsinfo.address[0].zip + "</li></div>" + cntm;  	

	}
	console.log("RESPADDR " + repsaddr);		
     var infowindow = new google.maps.InfoWindow({
    content: repsaddr,
    maxWidth: 200
});

     marker = new google.maps.Marker({
    position: myLatLng,
    map: map,
    animation: google.maps.Animation.DROP,
    title: repsinfo.name
  });
    
    
     


     console.log("marker & latlng " + marker.position + " " + myLatLng);
/*
     marker.addListener('click', function() {
    infowindow.open(map, marker);
    console.log("within infowindow " + marker);
});
*/

/*
	google.maps.event.addListener(marker, 'click', function() {
  infowindow.open(map,marker);
  console.log("within infowindow " + marker.position);
  });
*/

content = repsaddr;

google.maps.event.addListener(marker,'click', (function(marker,content,infowindow){ 
    return function() {
        infowindow.setContent(content);
        infowindow.open(map,marker);
    };
})(marker,content,infowindow));  

    markers[cntm] = marker;
    console.log("markers " + cntm + "" + markers[cntm].position);
    cntm++;
  
  
//    var len = data.length;
/*
    for (var i = 0; i < len; i++) {

          repsaddr += "<div><li> <a href=\"" + data[i].link + "\" target=\"_blank\">" + data[i].title + "</li></div>";

      }
      repsaddr += "</ul>";
      if(repsaddr.length === 0){
        repsaddr = "Quiet Town USA";
        }
    })
  */ 
  })
  //console.log("marker " + marker.position);
  

     
     

	
		
		}
	

}





/*
function showInfo(marker, content)
{
    // start div
    var div = "<div id='info'>";
    if (typeof(content) === "undefined")
    {
        // http://www.ajaxload.info/
        div += "<img alt='loading' src='img/ajax-loader.gif'/>";
    }
    else
    {
        div += content;
    }

    // end div
    div += "</div>";

    // set info window's content
    info.setContent(div);

    // open info window (if not already open)
    info.open(map, marker);
}
*/
/*
function getRepAddr(repsinfo)
{

	first = "geoaddr.php?address="
	repaddr = repsinfo.address[0].line1;
	repaddr += repsinfo.address[0].line2;
	repaddr += " " + repsinfo.address[0].city;
	repaddr += " " + repsinfo.address[0].state;
	repaddr += " " + repsinfo.address[0].zip;
	first += encodeURIComponent(repaddr);
	console.log("econde url " + first);


	$.getJSON(first)
   .done(function(data, textStatus, jqXHR) {
    console.log(data);

    myLatLng = data;
    console.log(myLatLng);

    return myLatLng;

	})

   
}
*/

/*
function initMap() {
  map = new google.maps.Map(document.getElementById('map'), {
    center: myLatLng,
    zoom: 8
  });
}  
async defer

&callback=initMap


*/